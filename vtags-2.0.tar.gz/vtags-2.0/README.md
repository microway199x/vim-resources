# Installation
    (1) uncompress vtag-x.xx.tar.gz and move to install path you want
    (2) add alias vtags.py to ~/.cshrc or ~/.bashrc depend on your system:
        for .cshrc  : alias vtags 'python <your install path>/vtags.py'
        for .bashrc : alias vtags='python <your install path>/vtags.py'
    (3) source .cshrc or .bashrc
    (4) add vtags_vim_api.vim to ~/.vimrc
        source <your install path>/vtags_vim_api.vim

# Complete documentation see the "vtags-x.xx/doc"
